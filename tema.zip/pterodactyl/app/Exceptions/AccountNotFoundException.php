<?php

namespace Pterodactyl\Exceptions;

use Exception;

class AccountNotFoundException extends Exception
{
}
